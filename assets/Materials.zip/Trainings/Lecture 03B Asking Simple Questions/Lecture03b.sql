-- delete all database first (if exists)
-- NOTE: reverse order of creation (why?)
DROP TABLE IF EXISTS enrolls;
DROP TABLE IF EXISTS teaches;
DROP TABLE IF EXISTS lecturers;
DROP TABLE IF EXISTS modules;
DROP TABLE IF EXISTS students;

-- create all necessary database
CREATE TABLE students (
  matric  VARCHAR NOT NULL PRIMARY KEY,
  sname   VARCHAR NOT NULL,
  intake  INT NOT NULL CHECK (intake > 1900)
);

CREATE TABLE modules (
  mcode   VARCHAR NOT NULL,
  sems    INT NOT NULL CHECK (sems > 0 AND sems < 5),
  mname   VARCHAR NOT NULL,
  credit  INT NOT NULL CHECK (credit > 3 AND credit < 6),
  PRIMARY KEY (mcode, sems)
);

CREATE TABLE lecturers (
  lname   VARCHAR NOT NULL PRIMARY KEY
);

CREATE TABLE teaches (
  lname   VARCHAR NOT NULL REFERENCES lecturers(lname),
  mcode   VARCHAR NOT NULL,
  sems    INT NOT NULL,
  FOREIGN KEY (mcode, sems) REFERENCES modules (mcode, sems),
  PRIMARY KEY (lname, mcode, sems)
);

CREATE TABLE enrolls (
  matric  VARCHAR NOT NULL REFERENCES students(matric),
  lname   VARCHAR NOT NULL,
  mcode   VARCHAR NOT NULL,
  sems    INT NOT NULL,
  grade   VARCHAR,
  FOREIGN KEY (lname, mcode, sems) REFERENCES teaches(lname, mcode, sems),
  PRIMARY KEY (matric, lname, mcode, sems)
);


-- insert test data
INSERT INTO students VALUES ('A0123456X', 'John Doe', 2001);
INSERT INTO students VALUES ('A0123457X', 'Jane Doe', 2001);
INSERT INTO students VALUES ('A0123458X', 'John Doe', 2003);
INSERT INTO students VALUES ('A0123459X', 'Doe', 2001);

INSERT INTO modules VALUES ('CS2102', 1, 'Database Systems', 4);
INSERT INTO modules VALUES ('CS2102', 2, 'Database Systems', 4);
INSERT INTO modules VALUES ('CS1101S', 1, 'Programming Methodology', 5);

INSERT INTO lecturers VALUES ('Adi');
INSERT INTO lecturers VALUES ('Prabawa');

INSERT INTO teaches VALUES ('Adi', 'CS2102', 1);
INSERT INTO teaches VALUES ('Prabawa', 'CS2102', 1);
INSERT INTO teaches VALUES ('Adi', 'CS2102', 2);
INSERT INTO teaches VALUES ('Prabawa', 'CS1101S', 1);

INSERT INTO enrolls VALUES ('A0123456X', 'Adi', 'CS2102', 1, null);
INSERT INTO enrolls VALUES ('A0123457X', 'Adi', 'CS2102', 1, 'F');
INSERT INTO enrolls VALUES ('A0123457X', 'Adi', 'CS2102', 2, null);
INSERT INTO enrolls VALUES ('A0123458X', 'Adi', 'CS2102', 2, 'A+');
INSERT INTO enrolls VALUES ('A0123459X', 'Adi', 'CS2102', 2, 'B-');