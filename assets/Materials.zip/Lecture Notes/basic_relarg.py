"""
NOTE: You do not need to know the details of this code
      This file is intended for you to practice
      relational algebra on your own.
      What matters is the usage.

Steps (assume you have Python installed):
1. Create a Python file F
2. Place file F in the same folder as this file
3. Type "from basic_relarg import *" (without quote)
   at the start of file F
4. Write your query as string Q
5. Call "print_table(complete(Q, db))" (without quote)
   to run the query Q

DISCLAIMER: This is a draft version.
"""


from pyparsing import *

# HELPER
def __op_val__(tokenlist):
  it = iter(tokenlist)
  while 1:
    try:
      yield (next(it), next(it))
    except StopIteration:
      break

def tracer():
  __dbg__ = False
  __num__ = 0
  def trace(loc, msg):
    nonlocal __num__
    __num__ += 1
    if __dbg__:
      num = str(__num__)
      while len(num) < 5:
        num = ' ' + num
      print(num, ">", loc, ":", msg)
  return trace
__trace__ = tracer()

def make_table(table):
  data, name = [], table["name"]
  for t_data in table["data"]:
    data.append(t_data.copy())
  return {
    'name': name,
    'head': list(map(lambda h: (name, h[1]), table['head'])),
    'data': data
  }

def project_head(head, columns):
  res = []
  for col in columns:
    res.append(head[col])
  return res
def project_data(data, columns):
  res = []
  for row in data:
    _row = []
    for col in columns:
      _row.append(row[col])
    if _row not in res:
      res.append(_row)
  return res

def compatible(tbl1, tbl2):
  # print(tbl1["head"])
  # print(tbl2["head"])
  return len(tbl1["head"]) == len(tbl2["head"])
def union(tbl1, tbl2):
  if compatible(tbl1, tbl2):
    data1, data2 = tbl1["data"], tbl2["data"]
    data = data1.copy()
    for row in data2:
      if row  not in data:
        data.append(row)
    name = tbl1["name"]
    return {
      'name': name,
      'head': list(map(lambda h: (name, h[1]), tbl1['head'])),
      'data': data
    }
  else:
    raise Exception(f"UNION_INCOMPATIBLE: {tbl1['name']} & {tbl2['name']}")
def intersection(tbl1, tbl2):
  if compatible(tbl1, tbl2):
    data1, data2 = tbl1["data"], tbl2["data"]
    data = []
    for row in data1:
      if row in data2:
        data.append(row)
    name = tbl1["name"]
    return {
      'name': name,
      'head': list(map(lambda h: (name, h[1]), tbl1['head'])),
      'data': data
    }
  else:
    raise Exception(f"UNION_INCOMPATIBLE: {tbl1['name']} & {tbl2['name']}")
def difference(tbl1, tbl2):
  if compatible(tbl1, tbl2):
    data1, data2 = tbl1["data"], tbl2["data"]
    data = []
    for row in data1:
      if row not in data2:
        data.append(row)
    name = tbl1["name"]
    return {
      'name': name,
      'head': list(map(lambda h: (name, h[1]), tbl1['head'])),
      'data': data
    }
  else:
    raise Exception(f"UNION_INCOMPATIBLE: {tbl1['name']} & {tbl2['name']}")
def cartesian(tbl1, tbl2):
  data1, data2 = tbl1["data"], tbl2["data"]
  head1, head2 = tbl1["head"], tbl2["head"]
  data , head  = [], head1 + head2
  for h in head1:
    if h in head2:
      raise Exception(f"DUPLICATE_ATTRIBUTE: {h[1]}")
  for h in head2:
    if h in head1:
      raise Exception(f"DUPLICATE_ATTRIBUTE: {h[1]}")
  for row1 in data1:
    row = []
    for row2 in data2:
      row.append(row1 + row2)
    data.append(row)
  name = tbl1["name"] + tbl2["name"]
  flat = []
  for r in data:
    flat.extend(r)
  # print("X", head, list(map(lambda h: (name, h[1]), head)))
  return {
    'name': name,
    'head': list(map(lambda h: (name, h[1]), head)),
    'data': flat
  }



# CLASS: Parse Actions
class Int():
  def __init__(self, tokens):
    self.val = tokens[0]
  def get_val(self, row, tbl):
    __trace__("Int", tbl)
    __trace__("Int", row)
    __trace__("Int", int(self.val))
    try:
      return int(self.val)
    except:
      raise Exception(f"NOT_A_NUMBER: {self.val}")
  def eval(self, row):
    return int(self.val)
  def string(self):
    return self.val
class Var():
  def __init__(self, tokens):
    self.val = tokens[0]
  def get_val(self, row, tbl):
    __trace__("VAR", tbl)
    __trace__("VAR", row)
    key = (tbl, self.val)
    if key in row:
      __trace__("VAR", self.val)
      __trace__("VAR", row[key])
      return int(row[key])
    else:
      raise Exception(f"MISSING_ATTRIBUTE_NAME: {self.val}")
  def eval(self, row):
    return row[self.val]
  def string(self):
    return self.val
class Val():
  def __init__(self, tokens):
    self.val = tokens[0]
  def get_val(self, row, tbl):
    return int(self.val.get_val(row, tbl))
  def eval(self, row):
    return self.val.eval(row)
  def string(self):
    return self.val.string()
class Attr():
  def __init__(self, tokens):
    self.table = None
    self.attrs = None
    if len(tokens) == 1:
      self.attrs = tokens[0]
    elif len(tokens) == 3:
      self.table = tokens[0]
      self.attrs = tokens[2]
    else:
      err = []
      for _ in range(len(tokens)):
        tok = tokens.pop()
        if tok != '.':
          err.insert(0, tok)
      raise Exception(f"INVALID_ATTRIBUTE_NAME: {'.'.join(err)}")
  def get_val(self, row, tbl):
    __trace__("ATR", tbl)
    __trace__("ATR", row)
    if self.table != None:
      key = (self.table.string(), self.attrs.string())
    else:
      key = (tbl, self.attrs.string())
    if key in row:
      __trace__("ATR", key)
      __trace__("ATR", row[key])
      return int(row[key])
    else:
      if self.table != None:
        attr = self.table.string() + "." + self.attrs.string()
      else:
        attr = self.attrs.string()
      raise Exception(f"MISSING_ATTRIBUTE_NAME: {'.'.join(attr)}")
  def get_attr(self):
    if self.table != None:
      return (self.table.string(), self.attrs.string())
    else:
      return (None, self.attrs.string())
  # def eval(self, row):
  #   return self.attrs # TODO
  def string(self):
    if self.table != None:
      return self.table.string() + '.' + self.attrs.string()
    else:
      return self.attrs.string()

class RelOp():
  def __init__(self, tokens):
    self.val = tokens[0]
  def cond(self, row, tbl):
    l, op, r = self.val
    __trace__("SET", tbl)
    __trace__("SET", row)
    __trace__("SET", op )
    if op == '<':
      res = int(l.get_val(row, tbl)) <  int(r.get_val(row, tbl))
    if op == '>':
      res = int(l.get_val(row, tbl)) >  int(r.get_val(row, tbl))
    if op == '<=':
      res = int(l.get_val(row, tbl)) <= int(r.get_val(row, tbl))
    if op == '>=':
      res = int(l.get_val(row, tbl)) >= int(r.get_val(row, tbl))
    if op == '==':
      res = int(l.get_val(row, tbl)) == int(r.get_val(row, tbl))
    if op == '!=':
      res = int(l.get_val(row, tbl)) != int(r.get_val(row, tbl))
    __trace__("SET", res)
    return res
  # def eval(self, row):
  #   l, op, r = self.val
  #   if op == '<':
  #     return l.eval(row) <  r.eval(row)
  #   if op == '>':
  #     return l.eval(row) >  r.eval(row)
  #   if op == '<=':
  #     return l.eval(row) <= r.eval(row)
  #   if op == '>=':
  #     return l.eval(row) >= r.eval(row)
  #   if op == '==':
  #     return l.eval(row) == r.eval(row)
  #   if op == '!=':
  #     return l.eval(row) != r.eval(row)
  def string(self):
    l, op, r = self.val
    return l.string() + ' ' + op + ' ' + r.string()
class LogOp():
  def __init__(self, tokens):
    self.val = tokens[0]
  def cond(self, row, tbl):
    res = self.val[0].cond(row, tbl)
    __trace__("LOG", tbl)
    __trace__("LOG", row)
    __trace__("LOG", res)
    for op, val in __op_val__(self.val[1:]):
      if op == "/\\":
        res = res and val.cond(row, tbl)
      if op == "\\/":
        res = res or  val.cond(row, tbl)
      if op == "~":
        res = not val.cond(row, tbl)
    return res
  # def eval(self, row):
  #   res = self.val[0].eval(row)
  #   for op, val in __op_val__(self.val[1:]):
  #     if op == "/\\":
  #       res = res and val.eval(row)
  #     if op == "\\/":
  #       res = res or  val.eval(row)
  #   return res
  def string(self):
    res = str(self.val[0].string())
    for op, val in __op_val__(self.val[1:]):
      res = '(' + res +  ' ' + op + ' ' + val.string() + ')'
    return res

class Table():
  def __init__(self, tokens):
    if len(tokens) == 4:
      self.table = tokens[0]
      self.vars  = tokens[2]
    else:
      self.table = tokens[0]
      self.vars  = None
  def get_name(self):
    return self.table.string()
  def get_vars(self):
    if self.vars != None:
      return self.vars.get_list()
    else:
      return None
  def eval(self, data):
    tables = data["tables"]
    name   = self.get_name()
    __trace__("TBL", name)
    __trace__("TBL", tables)
    for table in tables:
      __trace__("TBL", table["name"])
      if table["name"] == self.get_name():
        __trace__("TBL", table)
        return make_table(table)
    raise Exception(f"TABLE_NOT_FOUND: {self.get_name()}")
  def string(self):
    if self.vars != None:
      return f"{self.table.string()}({self.vars.string()})"
    else:
      return f"{self.table.string()}"

class VarList():
  def __init__(self, tokens):
    self.vars = []
    for _ in range(len(tokens)):
      self.vars.insert(0, tokens.pop()[0])
  def get_list(self):
    return list(map(lambda v: v.string(), self.vars))
  def string(self):
    return ','.join(list(map(lambda e: e.string(), self.vars)))

class AttrList():
  def __init__(self, tokens):
    self.attrs = []
    for _ in range(len(tokens)):
      self.attrs.insert(0, tokens.pop()[0])
  def get_list(self):
    return list(map(lambda v: v.get_attr(), self.attrs))
  def string(self):
    return ','.join(list(map(lambda e: e.string(), self.attrs)))

class Select():
  def __init__(self, tokens):
    self.conds = tokens[1]
    self.table = tokens[3]
  def eval(self, data):
    table = self.table.eval(data)
    __trace__("_S_", table)
    rows  = []
    for rdata in table["data"]:
      row = dict(zip(table["head"], rdata))
      __trace__("_S_", row)
      if self.conds.cond(row, table["name"]) == True:
        rows.append(rdata)
    table["data"] = rows
    return table
  def string(self):
    __trace__("_S_", self.conds)
    return f"S({self.conds.string()}, {self.table.string()})"
class Project():
  def __init__(self, tokens):
    self.attrs = tokens[2]
    self.table = tokens[5]
  def eval(self, data):
    table = self.table.eval(data)
    attrs = self.attrs.get_list()
    __trace__("_P_", attrs)
    cols = []
    for _tbl,_hd in attrs:
      found, col = 0, 0
      for tbl,hd in table["head"]:
        if _tbl != None and _tbl == tbl and _hd == hd:
          found += 1
          cols.append(col)
        elif _tbl == None and _hd == hd:
          found += 1
          cols.append(col)
        col += 1
      if found == 0:
        raise Exception(f"ATTRIBUTE_NOT_FOUND: {'*' if _tbl == None else _tbl}.{_hd}")
      if found > 1:
        raise Exception(f"AMBIGUOUS_ATTRIBUTE: {'*' if _tbl == None else _tbl}.{_hd}")
    table["head"] = project_head(table["head"], cols)
    table["data"] = project_data(table["data"], cols)
    return table
  def string(self):
    __trace__("_P_", self.attrs)
    return f"P([{self.attrs.string()}], {self.table.string()})"
class Rename():
  def __init__(self, tokens):
    self.alter = tokens[1]
    self.table = tokens[3]
  def eval(self, data):
    table = self.table.eval(data)
    __trace__("_R_", self.alter.get_name())
    __trace__("_R_", self.alter.get_vars())
    __trace__("_R_", table)
    name = self.alter.get_name()
    head = self.alter.get_vars()
    table["name"] = name
    if head != None:
      if len(head) != len(table["head"]):
        raise Exception(f"HEADER_MISMATCH: expected length {len(table['head'])}, given {len(head)}")
      table["head"] = list(map(lambda h: (name, h), head))
    else:
      table["head"] = list(map(lambda h: (name, h[1]), table["head"]))
    return table
  def string(self):
    __trace__("_R_", self.alter)
    return f"R({self.alter.string()}, {self.table.string()})"

class Unary():
  def __init__(self, tokens):
    self.op = tokens[0]
  def eval(self, data):
    return self.op.eval(data)
  def string(self):
    __trace__("Una", self.op)
    return f"{self.op.string()}"
    
class SetOp():
  def __init__(self, tokens):
    self.val = tokens[0]
  def eval(self, data):
    res = self.val[0].eval(data)
    __trace__("SET", res)
    for op, val in __op_val__(self.val[1:]):
      if op == "|":
        res = union(res, val.eval(data))
      if op == "&":
        res = intersection(res, val.eval(data))
      if op == "-":
        res = difference(res, val.eval(data))
      if op == "*":
        res = cartesian(res, val.eval(data))
    __trace__("SET", res)
    return res
  def string(self):
    res = str(self.val[0].string())
    __trace__("SET", self.val)
    for op, val in __op_val__(self.val[1:]):
      res = '(' + res +  ' ' + op + ' ' + val.string() + ')'
    return res

class Algebra():
  def __init__(self, tokens):
    self.val = tokens[0]
  def eval(self, data):
    return self.val.eval(data)
  def string(self):
    __trace__("Alg", self.val)
    return self.val.string()




# Variables
__int_token__  = Word(nums).setParseAction(Int)
__var_token__  = Word(srange("[a-z_]")).setParseAction(Var)
__attr_token__ = ((__var_token__ + "." + __var_token__) | (__var_token__)).setParseAction(Attr)
__val_token__  = (__attr_token__ | __var_token__ | __int_token__).setParseAction(Val)

# Comma Separated List
__var_list__  = delimitedList(Group(__attr_token__)).setParseAction(VarList)
__attr_list__ = "[" + delimitedList(Group(__attr_token__)).setParseAction(AttrList) + "]"

# Operators
__rel_opr__ = oneOf("< <= > >= == !=")
__log_opr__ = oneOf("/\\ \\/ ~")
__set_opr__ = oneOf("- | & *")

# Condition
__rel_op__ = infixNotation(
  __val_token__,
  [
    (__rel_opr__, 2, opAssoc.LEFT, RelOp),
  ]
)
__log_op__ = infixNotation(
  __rel_op__,
  [
    (__log_opr__, 2, opAssoc.LEFT, LogOp),
  ]
)

# Table
__table__ = ((__var_token__ + "(" + __var_list__ + ")") | (__var_token__)).setParseAction(Table)

# Relational Algebra Placeholder
__algebra__ = Forward()

### Unary Operator
__select__   = ("S(" + __log_op__ + "," + __algebra__ + ")").setParseAction(Select)
__project__  = ("P(" + __attr_list__ + "," + __algebra__ + ")").setParseAction(Project)
__rename__   = ("R(" + __table__ + "," + __algebra__ + ")").setParseAction(Rename)
__unary_op__ = (__select__ | __project__ | __rename__ | __table__).setParseAction(Unary)

### Set Operator
__set_op__ = infixNotation(
  __unary_op__,
  [
    (__set_opr__, 2, opAssoc.LEFT, SetOp),
  ]
)

# Relational Algebra Content
__algebra__ <<= __set_op__
__algebra__.setParseAction(Algebra)


"""
Shape of data
{
  tables: [list of table as described below]
}
Shape of table
{
  name: relation name
  head: [list of headers]  # must be the same columns as data
        (table, header_name)
  data: [list of rows]     # must be the same columns as head
}
"""
class NULL:
  def copy(self):
    return NULL()
  def __str__(self):
    return "NULL()"
  def __repr__(self):
    return "NULL()"
db = {
    "tables": [
        {
            "name": "nult",
            "head": [("nult","nula")],
            "data": [[NULL()]]
        },
        {
            "name": "contains",
            "head": [("contains","pizza"), ("contains","ingredient")],
            "data": [
                [1, 1],
                [1, 2],
                [1, 3],
                [2, 4],
                [2, 5],
                [3, 4],
                [3, 6],
                [4, 1],
                [4, 7],
                [5, 8],
                [6, 8],
                [6, 9],
                [6, 1]
            ]
        },
        {
            "name": "pizzas",
            "head": [("pizzas","pizza")],
            "data": [[1],[2],[3],[4],[5],[6]]
        },
        {
            "name": "customers",
            "head": [("customers","cname"), ("customers","area")],
            "data": [
              [101, 504],
              [102, 503],
              [103, 502],
              [104, 500],
              [105, 500],
              [106, 501]
            ]
        },
        {
            "name": "restaurants",
            "head": [("restaurants","rname"), ("restaurants","area")],
            "data": [
              [901, 501],
              [902, 500],
              [903, 500],
              [904, 503],
              [905, 502]
            ]
        },
        {
            "name": "likes",
            "head": [("likes","cname"), ("likes","pizza")],
            "data": [
              [101, 3],
              [101, 4],
              [102, 2],
              [103, 2],
              [104, 2],
              [104, 6],
              [105, 1]
            ]
        },
        {
            "name": "sells",
            "head": [("sells","rname"), ("sells","pizza"), ("sells","price")],
            "data": [
              [901, 1, 24],
              [901, 3, 25],
              [901, 4, 19],
              [902, 6, 16],
              [903, 2, 23],
              [904, 5, 22],
              [905, 1, 17],
              [905, 3, 21]
            ]
        },
        {
          'name': 'dislikes',
          'head': [('dislikes', 'cname'), ('dislikes', 'pizza')],
          'data': [[101, 1], [101, 2], [101, 5], [101, 6], [102, 1], [102, 3], [102, 4], [102, 5], [102, 6], [103, 1], [103, 3], [103, 4], [103, 5], [103, 6], [104, 1], [104, 3], [104, 4], [104, 5], [105, 2], [105, 3], [105, 4], [105, 5], [105, 6], [106, 1], [106, 2], [106, 3], [106, 4], [106, 5], [106, 6]]
        },
        {
          'name': 'likesdislikes',
          'head': [('likesdislikes', 'ca'), ('likesdislikes', 'cb')],
          'data': [[101, 102], [101, 103], [101, 104], [101, 105], [101, 106], [102, 101], [102, 105], [102, 106], [103, 101], [103, 105], [103, 106], [104, 101], [104, 105], [104, 106], [104, 102], [104, 103], [105, 101], [105, 102], [105, 103], [105, 104], [105, 106]]
        }
    ]
}

db2 = {
    "tables": [
        {
            "name": "nult",
            "head": [("nult","nula")],
            "data": [[NULL()]]
        },
        {
            "name": "contains",
            "head": [("contains","pizza"), ("contains","ingredient")],
            "data": [
                [1, 1],
                [1, 2],
                [1, 3],
                [2, 4],
                [2, 5],
                [3, 4],
                [3, 6],
                [4, 1],
                [4, 7],
                [5, 8],
                [6, 8],
                [6, 9],
                [6, 1]
            ]
        },
        {
            "name": "pizzas",
            "head": [("pizzas","pizza")],
            "data": [[1],[2],[3],[4],[5],[6]]
        },
        {
            "name": "customers",
            "head": [("customers","cname"), ("customers","area")],
            "data": [
              [101, 504],
              [102, 503],
              [103, 502],
              [104, 500],
              [105, 500],
              [106, 501],
              [107, 501]
            ]
        },
        {
            "name": "restaurants",
            "head": [("restaurants","rname"), ("restaurants","area")],
            "data": [
              [901, 501],
              [902, 500],
              [903, 500],
              [904, 503],
              [905, 502]
            ]
        },
        {
            "name": "likes",
            "head": [("likes","cname"), ("likes","pizza")],
            "data": [
              [101, 3],
              [101, 4],
              [102, 2],
              [103, 2],
              [104, 2],
              [104, 6],
              [105, 1]
            ]
        },
        {
            "name": "sells",
            "head": [("sells","rname"), ("sells","pizza"), ("sells","price")],
            "data": [
              [901, 1, 24],
              [901, 3, 25],
              [901, 4, 19],
              [902, 6, 16],
              [903, 2, 23],
              [904, 5, 22],
              [905, 1, 17],
              [905, 3, 21]
            ]
        },
        {
          'name': 'dislikes',
          'head': [('dislikes', 'cname'), ('dislikes', 'pizza')],
          'data': [[101, 1], [101, 2], [101, 5], [101, 6], [102, 1], [102, 3], [102, 4], [102, 5], [102, 6], [103, 1], [103, 3], [103, 4], [103, 5], [103, 6], [104, 1], [104, 3], [104, 4], [104, 5], [105, 2], [105, 3], [105, 4], [105, 5], [105, 6], [106, 1], [106, 2], [106, 3], [106, 4], [106, 5], [106, 6], [107, 1], [107, 2], [107, 3], [107, 4], [107, 5], [107, 6]]
        },
        {
          'name': 'likesdislikes',
          'head': [('likesdislikes', 'ca'), ('likesdislikes', 'cb')],
          'data': [[101, 102], [101, 103], [101, 104], [101, 105], [101, 106], [101, 107], [102, 101], [102, 105], [102, 106], [102, 107], [103, 101], [103, 105], [103, 106], [103, 107], [104, 101], [104, 105], [104, 106], [104, 107], [104, 102], [104, 103], [105, 101], [105, 102], [105, 103], [105, 104], [105, 106], [105, 107]]
        }
    ]
}

def pad(val,l):
  sval = str(val)
  lval = len(sval)
  if type(val) == int:
    return " " + (' ' * (l - lval)) + sval + " "
  else:
    return " " + sval + (' ' * (l - lval)) + " "
  
def print_table(tbl):
  rowl = list(map(lambda x: len(x[1]), tbl[0]))
  
  for row in tbl[1]:
    for i in range(len(row)):
      if len(str(row[i])) > rowl[i]:
        rowl[i] = len(str(row[i]))

  print("+", end='')
  for i in rowl:
    print(("-"*(i+2))+"+", end='')
  print()

  print('|', end='')
  for i in range(len(tbl[0])):
    print(pad(tbl[0][i][1], rowl[i])+'|', end='')
  print()
  
  print("+", end='')
  for i in rowl:
    print(("-"*(i+2))+"+", end='')
  print()

  for row in tbl[1]:
    print('|', end='')
    for i in range(len(row)):
      print(pad(row[i], rowl[i])+'|', end='')
    print()
  
  print("+", end='')
  for i in rowl:
    print(("-"*(i+2))+"+", end='')
  print()
  print(len(tbl[1]), "results")

def complete(alg, db):
    table = __algebra__.parseString(alg)
##    print(table[0].string())
    res   = table[0].eval(db)
    rel   = [res['head']] + [res['data']]
    return rel
def algebra(alg, db):
    table = __algebra__.parseString(alg)
    res   = table[0].eval(db)
    rel   = res['data']
    return set(map(tuple, rel))
def tablify(alg, db, name):
    table = __algebra__.parseString(alg)
    res   = table[0].eval(db)
    return {
      "name": name,
      "head": res['head'],
      "data": res['data']
    }
